using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class Abilitazioni : System.Web.UI.Page
{
	
	protected void Page_Load(object sender, EventArgs e)
  {

		if (!IsPostBack)
		{
			//	----------------------------------------------------------------------------------------------------
			//	Carico i DropDownList per Societ� e Organization Unit
			//	----------------------------------------------------------------------------------------------------
			myParameter p;

			myParameters parSocieta = new myParameters();
			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flSocieta"] == "1")
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			parSocieta.Add((SqlParameter)p.CreateSQLParameter());
			//
			Helper.FillDropDownList(cboSocieta, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieta", parSocieta), "ceSocieta", "deSocieta", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola societ�, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			//if (cboSocieta.SelectedIndex == 0 && cboSocieta.Items.Count == 2) cboSocieta.SelectedIndex = 1;
			if (cboSocieta.Items.Count == 2)
			{ cboSocieta.SelectedIndex = 1; }
			else
			{ cboSocieta.SelectedIndex = 0; }
			
			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�; se non sono Admin solo la mia OrgUnit
			//	----------------------------------------------------------------------------------------------------
			myParameters parOrgUnit = new myParameters();
			if ((string)Session["flSocieta"] == "1" && cboSocieta.SelectedIndex == 0)
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			//{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString()); }
			parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
			//
			if ((string)Session["flOrgUnit"] == "1")
			{ p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, ""); }
			else
			{ p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, (string)Session["dsOrgUnit"]); }
			parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
			//
			Helper.FillDropDownList(cboOrgUnit, DBHelper.GetSPDataSet("BOL_sp_EstraiOrgUnit", parOrgUnit), "dsOrgUnit", "dsOrgUnit", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola Organization Unit, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			//if (cboOrgUnit.SelectedIndex == 0 && cboOrgUnit.Items.Count == 2) cboOrgUnit.SelectedIndex = 1;
			if (cboOrgUnit.Items.Count == 2)
			{ cboOrgUnit.SelectedIndex = 1; }
			else
			{ cboOrgUnit.SelectedIndex = 0; }

			//	----------------------------------------------------------------------------------------------------
			//	Se sono SuperAdmin posso gestire tutte le societ�, altrimenti solo quella dell'utente
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flSocieta"] == "1")
			{
				Panel_Societa.Visible = true;
			}
			else
			{
				cboSocieta.SelectedValue = (string)Session["dsCodSoc"];
				lblSocieta.Text = cboSocieta.SelectedItem.ToString();
				Visua_Societa.Visible = true;
			}

			//	----------------------------------------------------------------------------------------------------
			//	Se sono Admin posso gestire tutte le OrgUnit della mia societ�, altrimenti solo quella dell'utente
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flOrgUnit"] == "1")
			{
				Panel_OrgUnit.Visible = true;
			}
			else
			{
				lblOrgUnit.Text = (string)Session["dsOrgUnit"];
				Visua_OrgUnit.Visible = true;
			}
		}
	}

	protected void Page_LoadComplete(object sender, EventArgs e)
	{
		if (Panel_Errore.Visible == false)
			BindData();
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Carico dataset della tabella BOL_TB_UTENTI da mostrare nella datagrid
	//	----------------------------------------------------------------------------------------------------------------------------------------
	private void BindData()
	{
		Panel_None.Visible = true;
		Panel_Trovati.Visible = false;
		Panel_DelRevocati.Visible = false;
		dgUtenti.Visible = false;
		//
		DataSet ds;
		ds = GetUtenti(cboSocieta.SelectedValue.ToString(), cboOrgUnit.SelectedValue.ToString(), txtRicerca.Text.ToString(), rblTipo.SelectedValue, ckb_Emetti.Checked, ckb_Riepil.Checked, ckb_Data.Checked);
		if (ds.Tables[0].Rows.Count > 0)
		{
			dgUtenti.DataSource = ds;
			dgUtenti.DataBind();
			dgUtenti.Visible = true;
			Panel_None.Visible = false;
			lbl_Numero.Text = ds.Tables[0].Rows.Count.ToString();
			Panel_Trovati.Visible = true;
			//
			if (rblTipo.SelectedValue == "R")
			{
				 Panel_DelRevocati.Visible = true;
			}
		}
		//else
		//{
			//Panel_None.Visible = true;
			//dgUtenti.Visible = false;
			//Panel_Trovati.Visible = false;
		//}
		return;
	}

	public static DataSet GetUtenti(string societa, string orgunit, string ricerca, string tipo, bool emetti, bool riepil, bool ordina)
	{
		myParameters collP = new myParameters();
		myParameter p;
		if (!string.IsNullOrEmpty(societa))
		{ 
			p = new myParameter("@Societa", SqlDbType.Char, 2, (string)societa);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(orgunit))
		{
			p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, (string)orgunit);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(ricerca) && ricerca.TrimEnd() != "")
		{
			p = new myParameter("@Ricerca", SqlDbType.VarChar, 50, (string)ricerca);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		//
		p = new myParameter("@Emetti", SqlDbType.Bit, 1, Convert.ToString(emetti));
		collP.Add((SqlParameter)p.CreateSQLParameter());
		p = new myParameter("@Riepil", SqlDbType.Bit, 1, Convert.ToString(riepil));
		collP.Add((SqlParameter)p.CreateSQLParameter());
		//
		DataSet ds;
		if (tipo == "A")
		{
			if (ordina)
			{
				ds = DBHelper.GetSPDataSet("BOL_sp_EstraiUtentiAttD", collP);
			}
			else
			{
				ds = DBHelper.GetSPDataSet("BOL_sp_EstraiUtentiAtt", collP);
			}
		}
		else
		{
			if (ordina)
			{
				ds = DBHelper.GetSPDataSet("BOL_sp_EstraiUtentiRevD", collP);
			}
			else
			{
				ds = DBHelper.GetSPDataSet("BOL_sp_EstraiUtentiRev", collP);
			}
		}
		return ds;
	}

	protected string SetCheckBox(Boolean valCampo)
	{
		if (valCampo)
			return "<img src='" + ResolveUrl("~/Images/check_on.gif") + "' alt='' />";
		else
			return "<img src='" + ResolveUrl("~/Images/check_off.gif") + "' alt='' />";
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Navigazione su elenco utenti
	//	----------------------------------------------------------------------------------------------------------------------------------------

	protected void btnCerca_Click(object sender, ImageClickEventArgs e)
	{
		dgUtenti.SelectedIndex = -1;
		dgUtenti.CurrentPageIndex = 0;
		Panel_Utente.Visible = false;
	}

	protected void ckb_Emetti_Changed(object sender, EventArgs e)
	{
		dgUtenti.SelectedIndex = -1;
		dgUtenti.CurrentPageIndex = 0;
		Panel_Utente.Visible = false;
	}

	protected void ckb_Riepil_Changed(object sender, EventArgs e)
	{
		dgUtenti.SelectedIndex = -1;
		dgUtenti.CurrentPageIndex = 0;
		Panel_Utente.Visible = false;
	}

	protected void ckb_Data_Changed(object sender, EventArgs e)
	{
		dgUtenti.SelectedIndex = -1;
		dgUtenti.CurrentPageIndex = 0;
		Panel_Utente.Visible = false;
	}

	protected void rblTipo_Changed(object sender, EventArgs e)
	{
		if (rblTipo.SelectedValue == "A")
		{ 
			lblOrdina.Text = "Ordina per data bolla:";
			cmd_Modifica.Visible = true;
		}
		else
		{ 
			lblOrdina.Text = "Ordina per data revoca:";
			cmd_Modifica.Visible = false;
		}
		ckb_Data.Checked = false;
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
	}

	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Navigazione su elenco utenti
	//	----------------------------------------------------------------------------------------------------------------------------------------

	public void dgUtenti_PageIndexChanged(object sender, DataGridPageChangedEventArgs e)
	{
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
		dgUtenti.CurrentPageIndex = e.NewPageIndex;
	}

	protected void cboVisua_SelectedIndexChanged(object sender, EventArgs e)
	{
		//dgUtenti.SelectedIndex = -1;
		dgUtenti.PageSize = Convert.ToInt32(cboVisua.SelectedValue);
		dgUtenti.CurrentPageIndex = 0;
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Visualizzazione dettaglio utente
	//	----------------------------------------------------------------------------------------------------------------------------------------
	protected void dgUtenti_Visualizza(object source, DataGridCommandEventArgs e)
	{
		switch (e.CommandName)
		{
			case "Expand":
				dgUtenti.SelectedIndex = e.Item.ItemIndex;
				Panel_Utente.Visible = true;
				break;

			case "Collapse":
				dgUtenti.SelectedIndex = -1;
				Panel_Utente.Visible = false;
				break;
		}
	}

	protected void dgUtenti_Dettaglio(object source, DataGridItemEventArgs e)
	{
		if (e.Item.DataItem != null)
		{
			ListItemType itemType = e.Item.ItemType;
			System.Web.UI.Control container = e.Item;

			if (itemType == ListItemType.SelectedItem)
			{
				//	----------------------------------------------------------------------------------------------------
				//	Cambio l'immagine dell'imagebutton
				//	----------------------------------------------------------------------------------------------------
				ImageButton btnExp = (ImageButton)container.FindControl("BtnExpand");
				btnExp.ImageUrl = "~/Images/cmd_comprimi.gif";
				btnExp.CommandName = "Collapse";
				btnExp.ToolTip = "Nascondi dettagli";

				//	----------------------------------------------------------------------------------------------------
				//	Ricerca dettagli utente selezionato
				//	----------------------------------------------------------------------------------------------------
				//Utente VisUtente = new Utente((dgUtenti.DataKeys[e.Item.ItemIndex]).ToString(), rblTipo.SelectedValue);
				Utente VisUtente = new Utente((dgUtenti.DataKeys[e.Item.ItemIndex]).ToString());
				ViewState["Utente"] = VisUtente;
				utGid.Text = VisUtente.ceGid;
				utNome.Text = VisUtente.dsCognome + " " + VisUtente.dsNome;
				utSocieta.Text = VisUtente.dsCodSoc + " - " + VisUtente.deSocieta;
				utOrgUnit.Text = VisUtente.dsOrgUnit;
				utLocalita.Text = VisUtente.dsLocalita;
				utTipoUtente.Text = VisUtente.dsTipoUtente;
				utBolleSt.Text = VisUtente.nmBolleSt;
				utBolleAC.Text = VisUtente.nmBolleAC;
				ckbEmetti.Checked = VisUtente.flEmetti;
				ckbRiepilogo.Checked = VisUtente.flRiepilogo;
				ckbOrgUnit.Checked = VisUtente.flOrgUnit;
				ckbAdmin.Checked = VisUtente.flAdmin;
				ckbSocieta.Checked = VisUtente.flSocieta;
				Panel_Funzioni.Visible = true;
				if ((string)Session["flSuper"] == "1") Panel_Admin.Visible = true;
				Panel_Comandi.Visible = true;
			}
		}
	}


	
	//	----------------------------------------------------------------------------------------------------
	//	Operazione cancellazione utenti revocati (tutti)
	//	----------------------------------------------------------------------------------------------------
	protected void cmdDelRevocati_OnClick(object sender, EventArgs e)
	{
		myParameters collP = new myParameters();
		myParameter p;
		if (!string.IsNullOrEmpty(cboSocieta.SelectedValue.ToString()))
		{
			p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString());
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(cboOrgUnit.SelectedValue.ToString()))
		{
			p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, cboOrgUnit.SelectedValue.ToString());
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(txtRicerca.Text.ToString()) && txtRicerca.Text.ToString().TrimEnd() != "")
		{
			p = new myParameter("@Ricerca", SqlDbType.VarChar, 50, txtRicerca.Text.ToString());
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_DeleteRevocati", collP);
		dr.Close();
		Panel_DelRevocati.Visible = false;
		Panel_Utente.Visible = false;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Operazione su utente selezionato
	//	----------------------------------------------------------------------------------------------------
	protected void cmdModifica_OnClick(object sender, EventArgs e)
	{
		Utente updUtente;
		updUtente = (Utente)ViewState["Utente"];
		updUtente.flAdmin = ckbAdmin.Checked;
		updUtente.flEmetti = ckbEmetti.Checked;
		updUtente.flRiepilogo = ckbRiepilogo.Checked;
		updUtente.flSocieta = ckbSocieta.Checked;
		updUtente.flOrgUnit = ckbOrgUnit.Checked;
		updUtente.Modifica_Utente();
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
	}

	protected void cmdElimina_OnClick(object sender, EventArgs e)
	{
		Utente delUtente;
		delUtente = (Utente)ViewState["Utente"];
		delUtente.Elimina_Utente();
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
	}
	

	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Societ�
	//	----------------------------------------------------------------------------------------------------
	protected void cboSocieta_SelectedIndexChanged(object sender, EventArgs e)
	{
		//	----------------------------------------------------------------------------------------------------
		//	Ricarico il DropDownList per Organization Unit
		//	----------------------------------------------------------------------------------------------------
		myParameter p;
		myParameters parOrgUnit = new myParameters();
		p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString());
		parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
		p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, "");
		parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
		Helper.FillDropDownList(cboOrgUnit, DBHelper.GetSPDataSet("BOL_sp_EstraiOrgUnit", parOrgUnit), "dsOrgUnit", "dsOrgUnit", null, null, null);
		//	----------------------------------------------------------------------------------------------------
		//	Se risulta una sola Organization Unit, la si seleziona e si carica il DropDownList per Centri di Costo
		//	----------------------------------------------------------------------------------------------------
		if (cboOrgUnit.Items.Count == 2) cboOrgUnit.SelectedIndex = 1;
		//
		//	----------------------------------------------------------------------------------------------------
		//	Inizializzazione pannello utenti
		//	----------------------------------------------------------------------------------------------------
		dgUtenti.CurrentPageIndex = 0;
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Organization Unit
	//	----------------------------------------------------------------------------------------------------
	protected void cboOrgUnit_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgUtenti.CurrentPageIndex = 0;
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
	}

}
