using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
  protected void Page_Load(object sender, EventArgs e)
  {
		//	----------------------------------------------------------------------------------------------------
		//	Se non � PostBack memorizzo i dati di Sessione del CurrentUser
		//	----------------------------------------------------------------------------------------------------
		if (!Page.IsPostBack || Session["ceGid"] == null)
		{
			if (Session["ceGid"] == null || (string)Session["ceGid"] == "")
			{
				Session["ceGid"] = GidCurrentUser();
				Utente User = new Utente((string)Session["ceGid"]);
				if (User.ceGid !=  "")
				{
					//	----------------------------------------------------------------------------------------------------
					//	Memorizzo le variabili di sessione per il CurrentUser
					//	----------------------------------------------------------------------------------------------------
					Session["ceGid"] = User.ceGid;
					Session["dsUserName"] = User.dsCognome.TrimEnd() + " " + User.dsNome.TrimEnd();
					Session["dsMainEmail"] = User.dsMainEmail;
					Session["dsCodSoc"] = User.dsCodSoc;
					Session["dsOrgUnit"] = User.dsOrgUnit;
					Session["dsSede"] = User.dsSede;
					Session["dsLocalita"] = User.dsLocalita;
					Session["flSuper"] = ((bool)User.flSuper ? "1" : "0");
					Session["flAdmin"] = ((bool)User.flAdmin ? "1" : "0");
					Session["flEmetti"] = ((bool)User.flEmetti ? "1" : "0");
					Session["flRiepilogo"] = ((bool)User.flRiepilogo ? "1" : "0");
					Session["flOrgUnit"] = ((bool)User.flOrgUnit ? "1" : "0");
					Session["flSocieta"] = ((bool)User.flSocieta ? "1" : "0");
					if (User.flEmetti || User.flRiepilogo || User.flAdmin)
					{ Session["isAbilitato"] = "1"; }
					else
					{ Session["isAbilitato"] = "0";}
				}
				else
				{
					Response.Redirect(System.Configuration.ConfigurationManager.AppSettings["Login"]);
				}

				//	----------------------------------------------------------------------------------------------------
				//	Ricerco i dati per la numerazione delle bolle per l'anno in corso
				//	----------------------------------------------------------------------------------------------------
				Numeri Num_Anno = new Numeri();
				if ((string)Session["flSocieta"] == "1")
				{ Num_Anno.CercaNumeri(null, Convert.ToString(DateTime.Today.Year)); }
				else
				{ Num_Anno.CercaNumeri((string)Session["dsCodSoc"], Convert.ToString(DateTime.Today.Year)); }
				Session["NumAnno"] = (string)Num_Anno.ceAnno;
			}

			//	----------------------------------------------------------------------------------------------------
			//	Memorizzo le label per l'intestazione della pagina
			//	----------------------------------------------------------------------------------------------------
			//lblUserName.Text = (string)Session["dsUserName"];
			//lblLocalita.Text = (string)Session["dsLocalita"];
			if ((string)Session["NumAnno"] != "0")
			{
				//	----------------------------------------------------------------------------------------------------
				//	Visualizzazione voci men� in funzione delle abilitazioni
				//	----------------------------------------------------------------------------------------------------
				if ((string)Session["flAdmin"] == "1")
				{
					Menu_Amm.Visible = true;
					Menu_Est.Visible = true;
				} 
				//
				if ((string)Session["flEmetti"] == "1" || (string)Session["flRiepilogo"] == "1")
				{ 
					Menu_Gest.Visible = true;
					//Mn_Ricerca.Visible = true;
					if ((string)Session["flEmetti"] == "1")
					{
						Menu_Emetti.Visible = true;
						Menu_Anag.Visible = true;
					}
					if ((string)Session["flRiepilogo"] == "1")
					{
						Menu_Riepilogo.Visible = true;
						if ((string)Session["flAdmin"] == "1") Menu_Storico.Visible = true;
					}
				}
			}
		}
	}

	//	----------------------------------------------------------------------------------------------------
	//	Recupero il GID dai Cookies
	//	----------------------------------------------------------------------------------------------------
	protected string GidCurrentUser()
	{
		string cmsCookie;
		string gid;
		string dominio = System.Configuration.ConfigurationManager.AppSettings["dominio"];

		if (Request.PhysicalApplicationPath == "d:\\iti08641\\My Documents\\Visual Studio 2005\\WebSites\\Numero_Bolla\\")
		{
			return ("Z000GT9P");	//log fisso Geppo
		}

		if (System.Web.HttpContext.Current.Request.Cookies["SIEAccessToken"] != null)
		{
			cmsCookie = System.Web.HttpContext.Current.Request.Cookies["SIEAccessToken"].Value;
			gid = System.Web.HttpContext.Current.Request.Cookies["SIEACCESSUSERPROFILE"].Value.Replace("USERNAME%3DWinNT%3A%2F%2F" + dominio + "%2F", "").Split('%')[0].ToString();
			return gid;
		}
		else
		{
            return ("Z0004JRK");
			//return null;
		}
	}

}
