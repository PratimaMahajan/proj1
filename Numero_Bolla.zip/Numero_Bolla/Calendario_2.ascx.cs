using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;


public partial class Calendario_2 : System.Web.UI.UserControl
{
  protected void Page_Load(object sender, EventArgs e)
	{
		//	----------------------------------------------------------------------------------------------------
		//	Se non � PostBack inizializzo la data con quella attuale
		//	----------------------------------------------------------------------------------------------------
		if (!IsPostBack)
		{
			set_Data_2_Sel(DateTime.Now);
		}
	}


	//	----------------------------------------------------------------------------------------------------
	//	Visualizzazione della data selezionata e memorizzazione su parametri di sessione
	//	----------------------------------------------------------------------------------------------------
	private void set_Data_2_Sel(DateTime data_Sel)
	{
		txt_Data_2.Text = data_Sel.ToShortDateString();
		txt_Data_2.Style["text-align"] = "center";
		Session["Data_A"] = txt_Data_2.Text;
		Session["DataA"] = data_Sel.Date;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Selezione nuova data
	//	----------------------------------------------------------------------------------------------------
	protected void Calendario_2_SelectionChanged(object sender, EventArgs e)
	{
		set_Data_2_Sel(calCalendario_2.SelectedDate);
	}


	protected void Calendario_2_MonthChanged(object sender, MonthChangedEventArgs e)
	{
		string scriptString = "<script language='JavaScript' id='Div&ImgVisible'>";
		scriptString = scriptString + "document.getElementById('Div_Calendario_2').style.visibility = 'visible';";
		scriptString = scriptString + "</script>";
		if (!Page.ClientScript.IsStartupScriptRegistered("Div&ImgVisible"))
			Page.ClientScript.RegisterStartupScript(typeof(Page), "Div&ImgVisible", scriptString);
	}

}
