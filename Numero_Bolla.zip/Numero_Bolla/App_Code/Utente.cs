using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Utente
/// </summary>
/// 


[Serializable()]

public class Utente
{
	private string _ceGid;
	private string _dsCognome;
	private string _dsNome;
	private string _dsMainEmail;
	private string _dsSede;
	private string _dsLocalita;
	private string _dsTipoUtente;
	private string _dsCodSoc;
	private string _deSocieta;
	private string _dsOrganization;
	private string _dsOrgUnit;
	//
	private DateTime _dtBolla;
	private bool _flSuper;
	private bool _flAdmin;
	private bool _flEmetti;
	private bool _flRiepilogo;
	private bool _flOrgUnit;
	private bool _flSocieta;
	private string _nmBolleAC;
	private string _nmBolleSt;
	//
	private string _dsCentroCosto;
	private string _dsTelefono;
	private string _dsNumFax;
	private string _dsCellulare;


	public string ceGid
	{
		get { return _ceGid; }
		set { _ceGid = value; }
	}

	public string dsCognome
	{
		get { return _dsCognome; }
	}

	public string dsNome
	{
		get { return _dsNome; }
	}

	public string dsMainEmail
	{
		get { return _dsMainEmail; }
	}

	public string dsSede
	{
		get { return _dsSede; }
	}

	public string dsLocalita
	{
		get { return _dsLocalita; }
	}

	public string dsTipoUtente
	{
		get { return _dsTipoUtente; }
		set { _dsTipoUtente = value; }
	}

	public string dsCodSoc
	{
		get { return _dsCodSoc; }
	}

	public string deSocieta
	{
		get { return _deSocieta; }
	}

	public string dsOrganization
	{
		get { return _dsOrganization; }
	}

	public string dsOrgUnit
	{
		get { return _dsOrgUnit; }
	}

	public DateTime dtBolla
	{
		set { _dtBolla = value; }
		get { return _dtBolla; }
	}

	public bool flSuper
	{
		get { return _flSuper; }
	}

	public bool flAdmin
	{
		set { _flAdmin = value; }
		get { return _flAdmin; }
	}

	public bool flEmetti
	{
		set { _flEmetti = value; }
		get { return _flEmetti; }
	}

	public bool flRiepilogo
	{
		set { _flRiepilogo = value; }
		get { return _flRiepilogo; }
	}

	public bool flOrgUnit
	{
		set { _flOrgUnit = value; }
		get { return _flOrgUnit; }
	}

	public bool flSocieta
	{
		set { _flSocieta = value; }
		get { return _flSocieta; }
	}

	public string nmBolleAC
	{
		get { return _nmBolleAC; }
	}

	public string nmBolleSt
	{
		get { return _nmBolleSt; }
	}

	//	----------------------------------------------------------------------------------------------------
	//	Dati dettagluo utente (ricerca anagrafica)
	//	----------------------------------------------------------------------------------------------------

	public string dsCentroCosto
	{
		get { return _dsCentroCosto; }
	}
	public string dsTelefono
	{
		get { return _dsTelefono; }
	}

	public string dsNumFax
	{
		get { return _dsNumFax; }
	}

	public string dsCellulare
	{
		get { return _dsCellulare; }
	}

	//	----------------------------------------------------------------------------------------------------
	//	Estrazione dati utente
	//	----------------------------------------------------------------------------------------------------
	public Utente(string GID)
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@de_GID", SqlDbType.VarChar, 16, GID);
		collP.Add(p.CreateSQLParameter());
		string sqlUtente = "";
		//if (tipo == "A")
		//{
			sqlUtente = "BOL_sp_GetUtente"; 
		//}
		//else
		//{ sqlUtente = "BOL_sp_GetUtenteRev"; }
		//
		SqlDataReader dr = DBHelper.GetSPReader(sqlUtente, collP);
		//
		if ((dr != null) && dr.Read())
		{
			_ceGid = dr["ceGid"].ToString();
			_dsCognome = dr["dsCognome"].ToString();
			_dsNome = dr["dsNome"].ToString();
			_dsMainEmail = dr["dsMainEmail"].ToString();
			_dsSede = dr["dsSede"].ToString();
			_dsLocalita = dr["dsLocalita"].ToString();
			_dsTipoUtente = dr["dsTipoUtente"].ToString();
			_dsCodSoc = dr["dsCodSoc"].ToString();
			_deSocieta = dr["deSocieta"].ToString();
			_dsOrganization = dr["dsOrganization"].ToString();
			_dsOrgUnit = dr["dsOrgUnit"].ToString();
			_dtBolla = Convert.ToDateTime(dr["dtBolla"].ToString());
			_flSuper = Convert.ToBoolean(dr["flSuper"].ToString());
			_flAdmin = Convert.ToBoolean(dr["flAdmin"].ToString());
			_flEmetti = Convert.ToBoolean(dr["flEmetti"].ToString());
			_flRiepilogo = Convert.ToBoolean(dr["flRiepilogo"].ToString());
			_flOrgUnit = Convert.ToBoolean(dr["flOrgUnit"].ToString());
			_flSocieta = Convert.ToBoolean(dr["flSocieta"].ToString());
			_nmBolleAC = dr["nmBolleAC"].ToString();
			_nmBolleSt = dr["nmBolleSt"].ToString();
			//
			_dsTelefono = dr["dsTelefono"].ToString();
			_dsNumFax = dr["dsNumFax"].ToString();
			_dsCellulare = dr["dsCellulare"].ToString();
			_dsCentroCosto = dr["dsPostoSpesa"].ToString();
		}
		else
		{
			_ceGid = "";
		}
		dr.Close();
	}


	//	----------------------------------------------------------------------------------------------------
	//	Modifica flags utente
	//	----------------------------------------------------------------------------------------------------
	public void Modifica_Utente()
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@de_GID", SqlDbType.VarChar, 16, _ceGid);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Admin", SqlDbType.Bit, 1, _flAdmin);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Emetti", SqlDbType.Bit, 1, _flEmetti);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Riepilogo", SqlDbType.Bit, 1, _flRiepilogo);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Societa", SqlDbType.Bit, 1, _flSocieta);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@OrgUnit", SqlDbType.Bit, 1, _flOrgUnit);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_UpdateUtente", collP);
	}

	//	----------------------------------------------------------------------------------------------------
	//	Aggiorna data ultima bolla utente
	//	----------------------------------------------------------------------------------------------------
	public void AggData_Utente()
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@de_GID", SqlDbType.VarChar, 16, _ceGid);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Data", SqlDbType.DateTime, 8, _dtBolla);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_UpdateUtenteDt", collP);
	}


	//	----------------------------------------------------------------------------------------------------
	//	Cancellazione utente
	//	----------------------------------------------------------------------------------------------------
	public void Elimina_Utente()
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@de_GID", SqlDbType.VarChar, 16, _ceGid);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_DeleteUtente", collP);
	}


	//	----------------------------------------------------------------------------------------------------
	//	Inserimento nuovo utente
	//	----------------------------------------------------------------------------------------------------
	public void Inserisci_Utente()
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@de_GID", SqlDbType.VarChar, 16, _ceGid);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Admin", SqlDbType.Bit, 1, _flAdmin);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Emetti", SqlDbType.Bit, 1, _flEmetti);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Riepilogo", SqlDbType.Bit, 1, _flRiepilogo);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@Societa", SqlDbType.Bit, 1, _flSocieta);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@OrgUnit", SqlDbType.Bit, 1, _flOrgUnit);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_InsertUtente", collP);
	}

}
