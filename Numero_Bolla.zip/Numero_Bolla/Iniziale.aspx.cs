using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Iniziale : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {
  }

	protected void Page_LoadComplete(object sender, EventArgs e)
	{
		if ((string)Session["isAbilitato"] == "0")
			{
				Panel_NoAbil.Visible = true;
				Panel_NoNUmero.Visible = false;
				Panel_Testo.Visible = false;
			}
			else
			{
				Panel_NoAbil.Visible = false;
				if ((string)Session["NumAnno"] == "0")
				{
					Panel_NoNUmero.Visible = true;
					Panel_Testo.Visible = false;
				}
				else
				{
					Panel_NoNUmero.Visible = false;
					Panel_Testo.Visible = true;
				}
			}
		//}
	}

}
