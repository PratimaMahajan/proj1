using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class RubricaClienti : System.Web.UI.Page
{

	protected void Page_Load(object sender, EventArgs e)
  {
		if (!IsPostBack)
		{
			myParameter p;

			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�
			//	----------------------------------------------------------------------------------------------------
			myParameters parSocieta = new myParameters();
			if ((string)Session["flSocieta"] == "1")
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			parSocieta.Add((SqlParameter)p.CreateSQLParameter());
			Helper.FillDropDownList(cboSocieta, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieta", parSocieta), "ceSocieta", "deSocieta", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola societ�, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			//if (cboSocieta.SelectedIndex == 0 && cboSocieta.Items.Count == 2) cboSocieta.SelectedIndex = 1;
			if (cboSocieta.Items.Count == 2)
			{ cboSocieta.SelectedIndex = 1; }
			else
			{ cboSocieta.SelectedIndex = 0; }

			//	----------------------------------------------------------------------------------------------------
			//	Segnalo che � necessario selezionare una Societ� e indicare un'OrgUnit o un nominativo da ricercare
			//	----------------------------------------------------------------------------------------------------
			Panel_Inizio.Visible = true;
		}
	}

	protected void Page_LoadComplete(object sender, EventArgs e)
	{
		Panel_Inizio.Visible = false;
		Panel_None.Visible = false;
		Panel_Trovati.Visible = false;
		Panel_Inizio.Visible = true;
		dgUtenti.Visible = false;

		//string socie = cboSocieta.SelectedValue;
		//if (!string.IsNullOrEmpty(txtRicerca.Text) && cboSocieta.SelectedIndex > 0)
		if (!string.IsNullOrEmpty(txtRicerca.Text) && !string.IsNullOrEmpty(cboSocieta.SelectedValue))
			{
			Panel_Inizio.Visible = false;
			BindData();
		}
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Carico dataset della tabella anagrafiche da mostrare nella datagrid
	//	----------------------------------------------------------------------------------------------------------------------------------------
	private void BindData()
	{
		DataSet ds;
		ds = GetUtenti(cboSocieta.SelectedValue.ToString(), txtRicerca.Text.ToString());
		if (ds.Tables[0].Rows.Count > 0)
		{
			dgUtenti.DataSource = ds;
			dgUtenti.DataBind();
			dgUtenti.Visible = true;
			lbl_Numero.Text = ds.Tables[0].Rows.Count.ToString();
			Panel_Trovati.Visible = true;
		}
		else
		{
			Panel_None.Visible = true;
		}
		return;
	}

	public static DataSet GetUtenti(string societa, string ricerca)
	{
		myParameters collP = new myParameters();
		myParameter p;
		if (!string.IsNullOrEmpty(societa))
		{
			p = new myParameter("@Societa", SqlDbType.Char, 2, (string)societa);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(ricerca) && ricerca.TrimEnd() != "")
		{
			p = new myParameter("@Ricerca", SqlDbType.VarChar, 50, (string)ricerca);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		DataSet ds;
		ds = DBHelper.GetSPDataSet("BOL_sp_EstraiUtentiRub", collP);
		return ds;
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Navigazione su elenco utenti
	//	----------------------------------------------------------------------------------------------------------------------------------------

	public void dgUtenti_PageIndexChanged(object sender, DataGridPageChangedEventArgs e)
	{
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
		dgUtenti.CurrentPageIndex = e.NewPageIndex;
	}

	protected void btnCerca_Click(object sender, ImageClickEventArgs e)
	{
		dgUtenti.SelectedIndex = -1;
		dgUtenti.CurrentPageIndex = 0;
		Panel_Utente.Visible = false;
	}

	protected void cboVisua_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgUtenti.PageSize = Convert.ToInt32(cboVisua.SelectedValue);
		dgUtenti.CurrentPageIndex = 0;
		Panel_Utente.Visible = false;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Societ�
	//	----------------------------------------------------------------------------------------------------
	protected void cboSocieta_SelectedIndexChanged(object sender, EventArgs e)
	{
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Visualizzazione dettaglio utente
	//	----------------------------------------------------------------------------------------------------------------------------------------
	protected void dgUtenti_Visualizza(object source, DataGridCommandEventArgs e)
	{
		switch (e.CommandName)
		{
			case "Expand":
				dgUtenti.SelectedIndex = e.Item.ItemIndex;
				Panel_Utente.Visible = true;
				break;

			case "Collapse":
				dgUtenti.SelectedIndex = -1;
				Panel_Utente.Visible = false;
				break;
		}
	}

	protected void dgUtenti_Dettaglio(object source, DataGridItemEventArgs e)
	{
		if (e.Item.DataItem != null)
		{
			ListItemType itemType = e.Item.ItemType;
			System.Web.UI.Control container = e.Item;

			if (itemType == ListItemType.SelectedItem)
			{
				//	----------------------------------------------------------------------------------------------------
				//	Cambio l'immagine dell'imagebutton
				//	----------------------------------------------------------------------------------------------------
				ImageButton btnExp = (ImageButton)container.FindControl("BtnExpand");
				btnExp.ImageUrl = "~/Images/cmd_comprimi.gif";
				btnExp.CommandName = "Collapse";
				btnExp.ToolTip = "Nascondi dettagli";

				//	----------------------------------------------------------------------------------------------------
				//	Ricerca dettagli utente selezionato
				//	----------------------------------------------------------------------------------------------------
				Utente VisUtente = new Utente((dgUtenti.DataKeys[e.Item.ItemIndex]).ToString());
				ViewState["Utente"] = VisUtente;
				utGid.Text = VisUtente.ceGid;
				utNome.Text = VisUtente.dsCognome + " " + VisUtente.dsNome;
				utSocieta.Text = VisUtente.dsCodSoc + " - " + VisUtente.deSocieta;
				utOrgUnit.Text = VisUtente.dsOrgUnit;
				utCentroCosto.Text = VisUtente.dsCentroCosto;
				utLocalita.Text = VisUtente.dsLocalita;
				utMainEmail.Text = VisUtente.dsMainEmail;
				utTelefono.Text = VisUtente.dsTelefono;
				utNumFax.Text = VisUtente.dsNumFax;
				utCellulare.Text = VisUtente.dsCellulare;
				//
				Session["utSocieta"] = VisUtente.dsCodSoc;
				Session["utOrgUnit"] = VisUtente.dsOrgUnit;
				Session["utCentroCosto"] = VisUtente.dsCentroCosto;
			}
		}
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Emissione bolla per anagrafica selezionata
	//	----------------------------------------------------------------------------------------------------------------------------------------
	protected void cmdNewBolla_OnClick(object sender, EventArgs e)
	{
		Response.Redirect(ResolveUrl("~/BollaEmetti.aspx"));
	}

}
